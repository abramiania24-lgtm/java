package utils;

public class ImageLoader {
    private String imagePath;

    }